#' main function cv.vcm (cross validation for the varying coefficient model, i.e., rDLR)
#' deals with cases:
#' 1. a pair of lambda_gr and lambda_fuse;
#' 2. path_lambda_fuse; 3. path_lambda_gr
#'
#' @param x matrix, predictor
#' @param response matrix
#' @param path_lambda_fuse vector of lambda for the fuse penalty, if NULL, use the default lambda sequence
#' @param path_lambda_gr vector of lambda for the group penalty, if NULL, use the default lambda sequence, same with path_lambda_fuse
#' @param response matrix
#' @param cv.type.measure criterion used to select the tuning parameter among the folders in the cv process
#' @param type.measure criterion used to in the function cvm
#'
#' @export
#'
#'
# this is for single pair of lambda_fuse and lambda_gr
# options(scipen = 999)
cv.vcm = function (x, response, family = "logit", fused_lasso = TRUE, group_lasso=TRUE
                , path_lambda_fuse = NULL, path_lambda_gr = 0.0, nlambda_fuse = 10
                , intercept = TRUE, standardize = TRUE
                , numFolds = 5, foldid = NULL, warm_start = FALSE
                , digit_nzero = 3
                , cv.type.measure = c("deviance")
                , break_lambda_fuse = TRUE
                , type.measure = c("deviance","misclass","auc") 
                , ABSTOL = 1e-4, RELTOL = 1e-2, num_iterADMM = 1e3
                , maxiter = 1, eps = 1e-16, eta = 2, cst_mu = 10, verbose=TRUE) {

  this.call    <- match.call()

  if (missing(type.measure)) {
    type.measure = "deviance" # "default"
  } else {
    type.measure = match.arg(type.measure)
  }

  if (!is.null(path_lambda_fuse) && length(path_lambda_fuse) < 2) stop("Need more than one value of path_lambda_fuse for cv.vcm")
  if (class(x) != "matrix") x = as.matrix(x)
  if (class(response) != "matrix") response = matrix(response, ncol=1)
  num_obs = nrow(x)

  vcm.call = match.call(expand.dots = TRUE)
  which = match(c("cv.type.measure", "nfolds", "foldid", "warm_start"
                ), names(vcm.call), FALSE)
  if (any(which)) {vcm.call = vcm.call[-which]}
  vcm.call[[1]] = as.name("vcm")

  vcm.object = vcm (x, response, family, fused_lasso, group_lasso
                    , path_lambda_fuse, path_lambda_gr, nlambda_fuse
                    , intercept, standardize
                    , type.measure
                    , break_lambda_fuse
                    , ABSTOL, RELTOL, num_iterADMM
                    , maxiter, eps, eta, cst_mu, verbose)
  vcm.object$call = vcm.call

  # according to the vcm.object results,
  # extract the path_lambda_fuse and path_lambda_gr to be used in cv
  if (length(vcm.object$path_lambda_gr) == 1){
    path_lambda_fuse = path_lambda_gr = c()
    path_lambda_fuse = vcm.object$path_lambda_fuse
    path_lambda_gr = vcm.object$path_lambda_gr
  } else if (length(vcm.object$path_lambda_gr) == 0){
    path_lambda_fuse = path_lambda_gr = c()
    path_lambda_fuse = vcm.object[[1]]$path_lambda_fuse
    tmp_lambda_gr = names(vcm.object)
    tmp_lambda_gr = tmp_lambda_gr[!(tmp_lambda_gr %in% "call")] # in the output vcm.object, there is an element "call"
    path_lambda_gr = as.numeric(sub(".*_", "", tmp_lambda_gr)) #vcm.object$path_lambda_gr
    # https://stackoverflow.com/questions/17215789/extract-a-substring-in-r-according-to-a-pattern

    if (break_lambda_fuse) {
      # extract the implemented path_lambda_fuse and path_lambda_gr
      num_subset = length(path_lambda_gr)
      
      tmp_store = vector(mode="list",num_subset)
      
      for (k in 1:num_subset) {
        tmp_path_lambda_gr = path_lambda_gr[k]
        tmp_path_lambda_fuse = vcm.object[[k]]$path_lambda_fuse
        tmp_store[[k]] = enlist(tmp_path_lambda_fuse, tmp_path_lambda_gr)
        # use the tmp_store so that later only perform the cv process on these specific pair of lambda values
      }
    } # end if-condition break_lambda_fuse
  } # end if condition

  res_foldid = cv_folds_full (n=num_obs, numFolds = numFolds, x, response)

  if (is.null(numFolds)) {
    numFolds = 5
  } else if (numFolds < 3) {
    stop("numFolds must be bigger than 3; numFolds=10 is recommended")
  }
  metric_misclass_list = metric_dev_list = metric_list = outlist = as.list(seq(numFolds))

  for (i in seq(numFolds)) {
    tmp_res_foldid = res_foldid[[i]]
    names(tmp_res_foldid) = names_foldid = c("xtest","xtrain","ytest","ytrain","xtest_id","xtrain_id","xtest_id_left","xtest_id_right","coef_index_left","coef_index_right","dist_prop","one_dist_prop")
    xsub = tmp_res_foldid$xtrain
    response_sub = tmp_res_foldid$ytrain

    if (break_lambda_fuse & length(vcm.object$path_lambda_gr) == 0) {
      seq_gr = seq(length(path_lambda_gr))
      store_outlist_gr = vector(mode= "list", length(seq_gr))

      # use the extracted implemented path_lambda_fuse and path_lambda_gr
      num_subset = length(path_lambda_gr)
      for (kk in 1:num_subset) {
        tmp_path_lambda_fuse = tmp_store[[kk]][[1]]
        tmp_path_lambda_gr = tmp_store[[kk]][[2]]

        store_outlist_gr[[kk]]= vcm (x = xsub, response = response_sub, family, fused_lasso, group_lasso
                            , path_lambda_fuse=tmp_path_lambda_fuse, path_lambda_gr=tmp_path_lambda_gr
                            , nlambda_fuse
                            , intercept, standardize
                            , type.measure
                            , break_lambda_fuse = FALSE
                            , ABSTOL, RELTOL, num_iterADMM
                            , maxiter, eps, eta, cst_mu, verbose)
      }
      outlist[[i]] = store_outlist_gr
      names(outlist[[i]]) = paste0("lambda_gr_",path_lambda_gr) # assuming at least one pair of lambda_fuse and lambda_gr works
      class(outlist[[i]]) = c("vcm", "list")
    } else {
      outlist[[i]] = vcm (x = xsub, response = response_sub, family, fused_lasso, group_lasso
                          , path_lambda_fuse, path_lambda_gr, nlambda_fuse
                          , intercept, standardize
                          , type.measure
                          , break_lambda_fuse = FALSE
                          , ABSTOL, RELTOL, num_iterADMM
                          , maxiter, eps, eta, cst_mu, verbose)
    }

    # obtain the coef on the xtest
    coef_mat_train_inlist = coef(outlist[[i]])  # outlist[[i]]$beta_mat_original_path # a list

    coef_index_left = tmp_res_foldid$coef_index_left
    coef_index_right = tmp_res_foldid$coef_index_right
    one_dist_prop = tmp_res_foldid$one_dist_prop
    dist_prop = tmp_res_foldid$dist_prop

    if (length(path_lambda_gr)==1) {
      if (length(path_lambda_fuse) != 1) {
        # case 1 a vector of lambda_fuse + a lambda_gr
        coef_mat_test_inlist = lapply(coef_mat_train_inlist, coefTest, coef_index_left, coef_index_right, one_dist_prop, dist_prop)
      } else {
        # coef_mat_train_inlist is only one element, is a mat
        coef_mat_test_inlist = coefTest(coef_mat=coef_mat_train_inlist, coef_index_left, coef_index_right, one_dist_prop, dist_prop)
      }
    } else {
      # case 2 a vector of lambda_fuse + a vector of lambda_gr
      coef_mat_test_inlist = as.list(seq(length(outlist[[i]])))
      for (j in 1:length(outlist[[i]])){
        coef_mat_test_inlist[[j]] = lapply(coef_mat_train_inlist[[j]], coefTest, coef_index_left, coef_index_right, one_dist_prop, dist_prop)
      }
    }

    # obtain the pred on the xtest
    xtest = tmp_res_foldid$xtest
    pred_test = predict_test(object=outlist[[i]], coef_test=coef_mat_test_inlist, xtest, type="response")
    if (class(pred_test)!= "matrix") pred_test = as.matrix(pred_test)
    colnames(pred_test) = extrat_names_list_list(coef_mat_test_inlist) # names_lambda (path_lambda_fuse, path_lambda_gr)


    if (cv.type.measure == "deviance") {
      metric_list[[i]] = sapply(data.frame(pred_test), metrics_dev, response=tmp_res_foldid$ytest)
    } else if (cv.type.measure == "misclass") {
      metric_list[[i]] = sapply(data.frame(pred_test), metrics, response=tmp_res_foldid$ytest, type = "misclass")
    }
   metric_dev_list[[i]] = sapply(data.frame(pred_test), metrics_dev, response=tmp_res_foldid$ytest)
   metric_misclass_list[[i]] = sapply(data.frame(pred_test), metrics, response=tmp_res_foldid$ytest, type = "misclass")

  } # end i-for loop

  cvraw = do.call(rbind, metric_list)
  cvm  <- apply(cvraw, 2, mean, na.rm = TRUE)
  cvsd <- apply(cvraw, 2, sd, na.rm = TRUE)
  cvup = lapply(1:length(cvm), function(m) cvm[[m]] + cvsd[[m]])
  cvlo = lapply(1:length(cvm), function(m) cvm[[m]] - cvsd[[m]])

  cvup = do.call(c, cvup)
  cvlo = do.call(c, cvlo)

  metric_dev_raw = do.call(rbind, metric_dev_list)
  metric_misclass_raw = do.call(rbind, metric_misclass_list)

  nzero = nzero.vcm(vcm.object, digit = digit_nzero)

  if (sum(as.numeric(nzero < num_obs))==0){
    cvmin = min(cvm) # case when all solutions requires df more than num.obs
  } else {
    which_cvmin = cvm %in% min(cvm[nzero < num_obs]) # obtain cvmin, after filtering the large nonzero cases
    cvmin = cvm[which_cvmin]
  }
  if(length(path_lambda_gr)==1){
    lambda_gr_cvmin = path_lambda_gr
    if(length(path_lambda_fuse)!=1){
      lambda_fuse_cvmin = path_lambda_fuse[which_cvmin]
    } else {
      which_cvmin = 1
      lambda_fuse_cvmin = path_lambda_fuse
    }
  } else {
    if (sum(which_cvmin) == 0) {
      which_cvmin[1] = TRUE # for the case when all coef does not satisfy the non_zero conditions
    }
    if (break_lambda_fuse) {
      options(scipen = 999) # important

      # https://stackoverflow.com/questions/14543627/extracting-numbers-from-vectors-of-strings
      lambda_fuse_cvmin = suppressWarnings(as.numeric(sapply(strsplit(names(cvmin), "_"), "[[", 3))) # position is checked by names(cvmin)
      lambda_gr_cvmin = suppressWarnings(as.numeric(sapply(strsplit(names(cvmin), "_"), "[[", 6)))
      # if NA in lambda_gr_cvmin happens, debug here first
    } else {
      lambda_index = which(which_cvmin==TRUE)

      lambda_index_gr = ceiling(lambda_index/length(path_lambda_fuse))
      lambda_index_fuse = lambda_index%%length(path_lambda_fuse)

      if (length(lambda_index_fuse) != 1) lambda_index_fuse=lambda_index_fuse[1] # for the case tie happens
      if (lambda_index_fuse == 0) lambda_index_fuse = lambda_index # for the case when mod = 0

      lambda_gr_cvmin = path_lambda_gr[lambda_index_gr]
      lambda_fuse_cvmin = path_lambda_fuse[lambda_index_fuse]
    }
  }

  out = enlist(path_lambda_fuse, path_lambda_gr, cvm, cvsd, cvup, cvlo, cvmin, which_cvmin
               , lambda_gr_cvmin, lambda_fuse_cvmin, nzero, break_lambda_fuse, metric_dev_raw, metric_misclass_raw, vcm.object)
  class(out) = c("cv.vcm", class(vcm.object))
  return (out)
  }

#' coef.cv.vcm
#'
#' @export coef.cv.vcm
# compute coef.cv.vcm
# lambda is based on lambda_min
coef.cv.vcm = function(object, s=NULL, break_lambda_fuse=TRUE, type="matrix", digit = NULL){

  if (length(object$path_lambda_gr)==1){
      # Case 2: path_lambda_fuse only
      # output: list with length equal to the length of path_lambda_fuse
    if (!is.null(object$vcm.object)) {
      coef_list = coef(object$vcm.object)
      lambda_index_gr = 1 # only one lambda_fuse
      lambda_index_fuse = which(object$path_lambda_fuse %in% object$lambda_fuse_cvmin)[1]
      out = coef_list[[lambda_index_fuse]]
      if (!is.null(digit)) out = round(out, digit=digit)
    } else {
        # case when initial path_lambda_fuse is vector, but the for-loop breaks,
        # thus, only one lambda_fuse value is computed
        out = object$beta_mat_original_path
      }
    } else {
    # Case 3: path_lambda_fuse and path_lambda_gr
    # output: a list of list where the element corresponds to each pair of lambda_fuse and lambda_gr
    coef_list = coef(object$vcm.object)
    lambda_index_gr = which(object$path_lambda_gr %in% object$lambda_gr_cvmin)[1] # path_lambda_gr order decreases
    #
    # object$path_lambda_fuse[lambda_index_fuse]
    if (break_lambda_fuse) {
      # use the name to track the ultimate element
      # because fuse is breaked depending on the argument
      out_tmp = coef_list[[lambda_index_gr]]
      name_tmp = names(out_tmp)
      lambda_index_fuse = which(as.numeric(sapply(strsplit(name_tmp, "_"), "[[", 3)) %in% object$lambda_fuse_cvmin)[1]
    } else {
      lambda_index_fuse = which(object$path_lambda_fuse %in% object$lambda_fuse_cvmin)[1]
    }
    out = coef_list[[lambda_index_gr]][[lambda_index_fuse]]

    if (!is.null(digit)) out = round(out, digit=digit)
  } # end if condition
  return(out)
}



#' object cv.vcm object
#' the default is using the cvmin from cv.vcm to obtain the coefficients
#' @export predict.cv.vcm
predict.cv.vcm = function(object, newx, s=NULL, type="matrix", digit = NULL){

  if (length(object$path_lambda_gr)==1){
    if (missing(newx)) newx = object$vcm.object$x
    if (object$vcm.object$intercept) {
      if (!all(newx[,1] == 1)) {
        newx = cbind(rep(1,nrow(newx)),newx)
      }
    }
  } else {
    if (missing(newx)) newx = object$vcm.object[[1]]$x
    if (object$vcm.object[[1]]$intercept) {
      if (!all(newx[,1] == 1)) {
        newx = cbind(rep(1,nrow(newx)),newx)
      }
    }
  }

  coeff = coef(object, s=s, type=type, digit = digit)

  pred = row_times_row(newx, coeff)
  return(pred)
}



# obtain the non-zero numbers in the estimated coefficients
# nzero is more like unique values
#' object cv.vcm object
#' @param object
#' @param digit
#'
#' @return
#'
#' @examples
#'
#' @export
nzero.vcm = function(object, digit=4){

  if (length(object$path_lambda_gr)==1){
    # case 1 a vector of lambda_fuse + a lambda_gr
    nzero = lapply(object$beta_mat_original_path, nonzero_vcm, digit = digit) # can also use nzero to cut the lambda fuse size at given lambda gr value
  } else if (length(object$path_lambda_gr)==0) {
    # case 2 a vector of lambda_fuse + a vector of lambda_gr
    nzero = as.list(seq(length(object)))
    for (j in 1:length(object)){
      tmp = coef(object[[j]]) # object[[j]]$beta_mat_original_path
      nzero[[j]] = lapply(tmp, nonzero_vcm, digit = digit)
    }
    nzero = do.call(c, nzero)
  } else {
    nzero = nzero.vcm(object$vcm.object, digit)
  }
  return(nzero)
}

nonzero_vcm=function(coeff, digit = 4){
  tmp = round(coeff, digit)
  if (class(tmp) == "numeric") tmp = as.matrix(tmp, ncol=1)

  out = 0
  for (j in 1:ncol(tmp)) {
    tmp_count = length(unique(tmp[,j]))
    if (0 %in% unique(tmp[,j])) tmp_count = tmp_count-1 # do not count zero in the coefficients
    out = out + tmp_count
  }
  return (out)
}

cv.vcm.logit = function(){
  # not used
}

#################################
# used inside of cv
# predict on the ytest in cv folds
#' @export
predict_test = function(object, coef_test, xtest, type="response"){

  newx = xtest
  if (length(object$path_lambda_gr)==1){
    # in the other case, object is a list of list
    if (object$intercept) {
      if (!all(newx[,1] == 1)) {
        newx = cbind(rep(1,nrow(newx)),newx)
      }
    }

    if (length(object$path_lambda_fuse)==1) {
      out = row_times_row(newx, coef_test) # out is a vector
    } else {
      # path_lambda_fuse only
      num = length(object$path_lambda_fuse)
      tmp = vector(mode="list",num)
      coeff = coef_test #coef.vcm(object,s) # coeff is a list
      for (kk in 1:num) {
        tmp[[kk]] = row_times_row(newx, coeff[[kk]])
      }
      out = do.call(cbind,tmp) # out is a matrix with each column corresponding to the predicted values from a value of lambda_fuse
    }
  } else {
    # path_lambda_fuse and path_lambda_gr
    # if (missing(newx)) newx = object[[1]]$x
    if (object[[1]]$intercept) {
      if (!all(newx[,1] == 1)) {
        newx = cbind(rep(1,nrow(newx)),newx)
      }
    }

    num_gr = length(object) # num of path_lambda_gr
    list_all = c()
    coeff = coef_test # coef.vcm(object,s) # coeff is a list
    for (i in 1:num_gr) {
      num_fuse = length(object[[i]]$path_lambda_fuse)
      tmp = vector(mode="list",(num_fuse))
      for (j in 1:num_fuse) {
        # id = (i-1)*num_fuse+j
        tmp[[j]] = row_times_row(newx, coeff[[i]][[j]])
      }
      list_all = c(list_all, tmp)
    }
    out = do.call(cbind,list_all)

    # out is a matrix with each column corresponding to the predicted values from a value of lambda_fuse
    # at one lambda_gr, the path of lambda_fuse; then repeat for the 2nd lambda_gr
  } # end else condition
  return(out)
}


# generate names for the columns of matrix, to show the corresponding lambda pair
names_lambda = function(path_lambda_fuse, path_lambda_gr){

  out = c()
  if (length(path_lambda_gr) == 1) {
    out = paste0("lam_fuse_",path_lambda_fuse,"_lam_gr_",path_lambda_gr)
  } else {
    for (j in 1:length(path_lambda_gr)){
      tmp = paste0("lam_fuse_",path_lambda_fuse,"_lam_gr_",path_lambda_gr[j])
      out = c(out, tmp)
    }
  }
  return (out)

}

extrat_names_list_list = function(list_list){
  num = length(list_list)
  res = c()
  for (i in 1:num) {
    names_tmp = names(list_list[[i]])
    res = c(res, names_tmp)
  }
  return(res)
}
