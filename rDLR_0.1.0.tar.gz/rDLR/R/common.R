#'  cv type for fuse lasso
#' # based on https://github.com/statsmaths/genlasso/blob/master/R/cv.trendfilter.R
#' @export
#'
cv_folds_full <- function (n, numFolds = 5, x, response) {
  pos = 1:n
  foldid = c(0,rep(seq(1,numFolds),n-2)[seq(1,n-2)],0)

  folds_rest = folds =  rep(list(NA),numFolds)
  for (i in 1:numFolds) {
    folds[[i]] = which(foldid == i)
    folds_rest[[i]] = which(foldid != i)
  }

  out = rep(list(-1),10) # the most inner layer
  out = rep(list(out),numFolds) # the most outer layer

  for (h in 1:numFolds) {
    o = folds[[h]]
    out[[h]][[1]] = xtest = as.matrix(x[o,])
    out[[h]][[2]] = xtrain = as.matrix(x[-o,])
    out[[h]][[3]] = ytest = as.matrix(response[o,])
    out[[h]][[4]] = ytrain = as.matrix(response[-o,])

    out[[h]][[5]] = o
    out[[h]][[6]] = o_rest = folds_rest[[h]]
    out[[h]][[7]] = o_left = which((seq(1,n)%in%(o-1)))
    out[[h]][[8]] = o_right = which((seq(1,n)%in%(o+1)))
    out[[h]][[9]] =  coef_index_left = which(o_rest %in% o_left)
    out[[h]][[10]] = coef_index_right = which(o_rest %in% o_right)
    out[[h]][[11]] = dist_prop = (o - o_left)/(o_right - o_left)
    out[[h]][[12]] = one_dist_prop = 1 - dist_prop
  }
  return(out)
}

#' @export

 coefTest = function(coef_mat, coef_index_left, coef_index_right, one_dist_prop, dist_prop){
   out = as.matrix(coef_mat[coef_index_left,]) * (one_dist_prop) + as.matrix(coef_mat[coef_index_right,]) * dist_prop
   return(out) # out is matrix
 }


 #' This function creates the different matrix with dim (n-1) x n
 #' where n is the length of the beta if beta is vector
 #' @examples
 #' diff_matrix(num_obs = 5)
 #' diff_matrix(num_obs = 5, sparse = FALSE)
 #'
 #' @export
 #'
 diff_matrix = function(num_obs, sparse = TRUE, num_col = 1){
   D1 = Matrix::bandSparse(num_obs, m = num_obs, k = c(0, 1),
                           diagonals = list(rep(x = -1, times = num_obs), rep(x = 1, times = (num_obs - 1))))
   
   # remove the row, which has row numID %% 10 is 0
   D1 = D1[-nrow(D1), ] # this D1 is the diff matrix for single column in beta
   
   # make a block diagonal matrix if there are multiple columns,
   # and each column has no relation, that is,
   # https://stackoverflow.com/questions/17495841/block-diagonal-binding-of-matrices
   out  = D1
   while (num_col > 1){
     out = Matrix::bdiag(out,D1)
     num_col = num_col - 1
   }
   
   if (sparse == FALSE) out = as.matrix(out)
   return(out)
 }
 
 
 #' This function creates the sparse diagonal matrix, n x n
 #' where n is the length of the beta if beta is vector
 #'
 #' @export
 #'
 diagonal_sp = function(n, sparse = TRUE){
   
   F2 = Matrix::bdiag(Matrix::Diagonal(n))
   out= as(F2, "dgCMatrix")
   
   if (sparse == FALSE) out = as.matrix(out)
   return(out)
 }
 
 
#' common utility functions
#' The author of this function is
#' Hastie, T., Tibshirani, R., and Tibshirani, R. J.
enlist <- function (...)
{
  result <- list(...)
  if ((nargs() == 1) & is.character(n <- result[[1]])) {
    result <- as.list(seq(n))
    names(result) <- n
    for (i in n) result[[i]] <- get(i)
  }
  else {
    n <- sys.call()
    n <- as.character(n)[-1]
    if (!is.null(n2 <- names(result))) {
      which <- n2 != ""
      n[which] <- n2[which]
    }
    names(result) <- n
  }
  result
}
