#' main function vcm (varying coefficient model in the work, that is, rDLR)
#' # deals with three cases: 1. a pair of lambda_gr and lambda_fuse; 2. path_lambda_fuse; 3. path_lambda_gr
#'
#' @param x matrix, predictor
#' @param response matrix
#' @param path_lambda_fuse vector of lambda for the fuse penalty, if NULL, use the default lambda sequence
#' @param path_lambda_gr vector of lambda for the group penalty, if NULL, use the default lambda sequence, same with path_lambda_fuse
#' @param response matrix
#' @param nlambda_fuse default value is 10. Used when path_lambda_fuse is not provided
#' @param type_measure criterion used to select the tuning parameter
#'
#' @export
#'
#'
# this is for single pair of lambda_fuse and lambda_gr
vcm = function (x, response, family = "logit", fused_lasso = TRUE, group_lasso=TRUE
                , path_lambda_fuse = NULL, path_lambda_gr = 0.0, nlambda_fuse = 10
                , intercept = FALSE, standardize = TRUE
                , type.measure = c("deviance","misclass","auc") # class is the misclassification error
                , break_lambda_fuse = FALSE
                , ABSTOL = 1e-4, RELTOL = 1e-2, num_iterADMM = 1e3
                , maxiter = 1, eps = 1e-16, eta = 2, cst_mu = 10, verbose=TRUE){
  # note, maxiter is obsolete
  # used in the Rcpp function updateX_logit_groupNfused_

  call = match.call()

  # Save original x
  x0 = x
  if (intercept) {
    if (!all(x[,1] == 1)) {
      x = cbind(rep(1,nrow(x)),x)
    }
  }
  # if no intercept, columns in x could be all 1, but that column is not meaningful

  # Center and scale, etc.
  # The lasso method requires initial standardization of the regressors, so that the penalization scheme is fair to all regressors.
  obj = x_standardize(x = x, intercept = intercept, standardize= standardize)
  x = obj$x # this x includes intercept column if intercept is true
  bx = obj$bx
  sx = obj$sx
  n.obs = nrow(x); n.vars = ncol(x)

  # lambda range
  if (is.null(path_lambda_fuse)) {
    cat("Warnings: I did not receive the arguments of path_lambda_fuse and path_lambda_gr.\n")
    cat("Using the default path_lambda_fuse and path_lambda_gr.\n")
    y_tmp <-  response-0.5 
    if (intercept) {
      tmp1 = x*as.vector(y_tmp)
      tmp1 = tmp1[,-1]
    } else {
      tmp1 = x*as.vector(y_tmp)
    }
    lamb_max = max(abs(tmp1)) /sqrt(nrow(response)) # nrow(response) # in the cpp code, used the multiple nrow(response)
    lamb_min = 1e-3 * lamb_max
    path_lambda_fuse = round(exp(seq(log(lamb_max), log(lamb_min),
                                     length.out = nlambda_fuse)), digits = 6)
    if (is.null(path_lambda_gr)) {
      path_lambda_gr = path_lambda_fuse
    }
  }
  if (is.null(path_lambda_gr)) {
    path_lambda_gr = 0 # fuse only case
  }

  # https://stackoverflow.com/questions/25257780/how-does-glmnet-compute-the-maximal-lambda-value/
  if (length(path_lambda_gr)==1){
    if (length(path_lambda_fuse)==1) {
      # Case: single pair (lambda_fuse, lambda_gr)
      lambda_gr = path_lambda_gr[1]
      lambda_fuse = path_lambda_fuse[1]
      res = admmLASSO_groupNfused_sep_(x, response, lambda_fuse = lambda_fuse, lambda_gr = lambda_gr, family = family
                                       , fused_lasso = fused_lasso, group_lasso = group_lasso, ABSTOL = ABSTOL, RELTOL = RELTOL, num_iterADMM = num_iterADMM
                                       , maxiter = 1, eps = eps, eta = eta, cst_mu = cst_mu
                                       , verbose=verbose)

      deviance = metrics_dev (response = res$response, fitted = res$fitted)
      auc = metrics (response = res$response, fitted = res$fitted, type = "auc")
      misclass = metrics (response = res$response, fitted = res$fitted, type = "misclass")

      beta_mat_original = return_original_scale(res, standardize, intercept, sx, bx)
      out = c(list(beta_mat_original=beta_mat_original, path_lambda_fuse = path_lambda_fuse, path_lambda_gr = path_lambda_gr), res
              ,list(intercept=intercept, standardize=standardize,x=x0, bx=bx,sx=sx, call=call))

    } else {
      ##############
      # path_lambda_fuse only
      if (is.null(path_lambda_gr)) {
        lambda_gr = 0.0
        if (verbose) print ("Warning: lambda_group is forced to be 0 in the case of fused lasso only.")
      } else {
        lambda_gr = path_lambda_gr[1]
      }

      if (n.obs <= n.vars) {
        stop("Error: the fused lasso penalty method fails when number of observations <= number of predictors.")
      }
      seq_fuse = seq(length(path_lambda_fuse))
      nzero_path = outloop = dev_path = auc_path = misclass_path = beta_mat_original_path = vector(mode= "list", length(seq_fuse)) #as.list(seq_fuse)

      for (i in seq_fuse){
        lambda_fuse = path_lambda_fuse[i]
        res = admmLASSO_groupNfused_sep_(x, response, lambda_fuse = lambda_fuse, lambda_gr = lambda_gr, family = family
                                         , fused_lasso = fused_lasso, group_lasso = group_lasso, ABSTOL = ABSTOL, RELTOL = RELTOL, num_iterADMM = num_iterADMM
                                         , maxiter = 1, eps = eps, eta = eta, cst_mu = cst_mu
                                         , verbose=verbose)
        outloop[[i]] = res
        dev_path[[i]] = metrics_dev (response = res$response, fitted = res$fitted)
        auc_path[[i]] = metrics (response = res$response, fitted = res$fitted, type = "auc")
        misclass_path[[i]] = metrics (response = res$response, fitted = res$fitted, type = "misclass")
        beta_mat_original_path[[i]] = return_original_scale(res, standardize, intercept, sx, bx)
        digit_nzero = 3
        nzero_path[[i]] = nonzero_vcm(beta_mat_original_path[[i]], digit = digit_nzero)
        if (break_lambda_fuse & (nzero_path[[i]] > n.obs)) break; 
      }
      if (TRUE){
        dev_path_vec = do.call(c,dev_path)
        dev_path_vec_tmp = dev_path_vec[do.call(c, nzero_path)<n.obs] # remove case nonzero > number observations
        if (length(dev_path_vec_tmp)==0){
          # all solutions have num of estimates greater than n.obs
          lambda_fuse_id = c(TRUE, rep(FALSE, times=(length(path_lambda_fuse)-1)))
        } else {
          lambda_fuse_id = dev_path_vec %in% min(dev_path_vec_tmp)
        }
      } # end if condition
      if (TRUE){ 
        auc_path_vec = do.call(c,auc_path)
        auc_path_vec_tmp = auc_path_vec[do.call(c, nzero_path)<n.obs]
        if (length(auc_path_vec_tmp)==0){
          # all solutions have num of estimates greater than n.obs
          lambda_fuse_id = c(TRUE, rep(FALSE, times=(length(path_lambda_fuse)-1)))
        } else {
          lambda_fuse_id = auc_path_vec %in% min(auc_path_vec_tmp)
        }
      }
      if (TRUE){ 
        misclass_path_vec = do.call(c,misclass_path)
        misclass_path_vec_tmp = misclass_path_vec[do.call(c, nzero_path)<n.obs]
        if (length(misclass_path_vec_tmp)==0){
          # all solutions have num of estimates greater than n.obs
          lambda_fuse_id = c(TRUE, rep(FALSE, times=(length(path_lambda_fuse)-1)))
        } else {
          lambda_fuse_id = misclass_path_vec %in% min(misclass_path_vec_tmp)
        }
      }
      lambda_fuse_id_numeric = which(lambda_fuse_id==TRUE)
      if (length(lambda_fuse_id_numeric) > 1) {
        lambda_fuse_id_numeric = lambda_fuse_id_numeric[1]
        # when more than one lambda_fuse}_id, choose the first one, which has larger lambda value
      } else if (length(lambda_fuse_id_numeric)==0) {
        # all results have more than n.obs estimates, not good
        lambda_fuse_id_numeric = 1 # place holder
      }
      res = outloop[[lambda_fuse_id_numeric]]
      deviance = dev_path_vec[lambda_fuse_id]
      auc = auc_path_vec[lambda_fuse_id]
      misclass = misclass_path_vec[lambda_fuse_id]

      # note
      # beta_mat_original_path is actually z2 from the cpp code

      path_lambda_fuse= path_lambda_fuse[1:i] # i is the index when the for-loop breaks
      beta_mat_original_path=beta_mat_original_path[1:i]
      names(beta_mat_original_path) = paste0("lam_fuse_",path_lambda_fuse,"_lam_gr_",lambda_gr)
      out = c(list(beta_mat_original_path=beta_mat_original_path,deviance=deviance, auc=auc, misclass=misclass,lambda_fuse_id=lambda_fuse_id
                   ,outloop=outloop,dev_path=do.call(c,dev_path),auc_path=do.call(c,auc_path),misclass_path=do.call(c,misclass_path)
                   ,nzero_path=do.call(c,nzero_path)
                   , path_lambda_fuse = path_lambda_fuse, path_lambda_gr = path_lambda_gr)
              , res,list(intercept=intercept, standardize=standardize,x=x0, bx=bx,sx=sx, call=call))

    } # end path_lambda_fuse only
  } else {
    # Case: path_lambda_fuse and path_lambda_gr
    seq_gr = seq(length(path_lambda_gr))

    outlist_gr = vector(mode= "list", length(seq_gr))

    for (j in seq_gr){
      # apply the function inside the function with different arguments
      x = x0 # feed the original x
      outlist_gr[[j]]=vcm (x, response, family = family, fused_lasso = fused_lasso, group_lasso=group_lasso
                       , path_lambda_fuse = path_lambda_fuse, path_lambda_gr = path_lambda_gr[j]
                       , intercept = intercept, standardize = standardize
                       , type.measure = type.measure # class is the misclassification error
                       , break_lambda_fuse = break_lambda_fuse
                       , ABSTOL = ABSTOL, RELTOL = RELTOL, num_iterADMM = num_iterADMM
                       , maxiter = maxiter, eps = eps, eta = eta, cst_mu = cst_mu, verbose=verbose)
    }
    out = outlist_gr
    # assign the name in list
    names(out) = paste0("lambda_gr_",path_lambda_gr)
  }

  class(out) = "vcm"
  return(out)
}


# type: matrix means the coefficients beta are in matrix format; vector means they are stacked column-wise
#' coef.vcm
#' @param object
#' @param s
#'
#' @export coef.vcm
coef.vcm = function(object, s=NULL, type = "matrix"){

  if (length(object$path_lambda_gr)==1){
    if (length(object$path_lambda_fuse)==1) {
      # Case 1: single pair (lambda_fuse, lambda_gr)
      coeff = object$beta_mat_original
      if (type == "vector") {
        coeff=as.vector(coeff)
      }
    } else {
      # Case 2: path_lambda_fuse only
      # output: list with length equal to the length of path_lambda_fuse
      coeff = object$beta_mat_original_path
      if (type == "vector") {
        coeff=sapply(coeff, as.vector)
      }

    }
  } else {
    # Case 3: path_lambda_fuse and path_lambda_gr
    # output: a list of list where the element corresponds to each pair of lambda_fuse and lambda_gr
    tmp_lambda_gr = names(object)
    tmp_lambda_gr = tmp_lambda_gr[!(tmp_lambda_gr %in% "call")] # in the output vcm.object, there is an element "call"
    path_lambda_gr = as.numeric(sub(".*_", "", tmp_lambda_gr)) #vcm.object$path_lambda_gr

    coeff = vector(mode= "list", length(path_lambda_gr))
    num_gr = length(path_lambda_gr)
    for (i in 1:num_gr) {
      
      if (is.null(object[[i]]$beta_mat_original_path)) {
        mat1 = object[[i]]$beta_mat_original # due to different output name
        if (class(mat1) == "matrix") {
          coeff[[i]] = enlist(mat1) # convert to list
          names(coeff[[i]]) = paste0("lam_fuse_",object[[i]]$path_lambda_fuse,"_lam_gr_",object[[i]]$path_lambda_gr)
        }
      } else {
        coeff[[i]] = object[[i]]$beta_mat_original_path
      } # end if-null condition
    }
    if (type == "vector") {
      # such that the beta is in column format
      # for a series lambda, the output is a matrix
      tmp = lapply(coeff, sapply, as.vector)
      coeff = do.call(cbind, tmp)
    }

  } # end if condition
  return(coeff)
}


#' predict.vcm
#' @param object
#' @param newx
#' @export predict.vcm
predict.vcm = function(object, newx, s=NULL, type="response"){

  if (length(object$path_lambda_gr)==1){
    # in the other case, object is a list of list
    if (missing(newx)) newx = object$x
    if (object$intercept) {
      if (!all(newx[,1] == 1)) {
        newx = cbind(rep(1,nrow(newx)),newx)
      }
    }

    if (length(object$path_lambda_fuse)==1) {
      out = row_times_row(newx, coef.vcm(object,s)) # out is a vector
    } else {
      # path_lambda_fuse only
      num = length(object$path_lambda_fuse)
      tmp = vector(mode="list",num)
      coeff = coef.vcm(object,s) # coeff is a list
      for (i in 1:num) {
        tmp[[i]] = row_times_row(newx, coeff[[i]])
      }
      out = do.call(cbind,tmp) # out is a matrix with each column corresponding to the predicted values from a value of lambda_fuse
    }
  } else {
    # path_lambda_fuse and path_lambda_gr
    if (missing(newx)) newx = object[[1]]$x
    if (object[[1]]$intercept) {
      if (!all(newx[,1] == 1)) {
        newx = cbind(rep(1,nrow(newx)),newx)
      }
    }

    num_gr = length(object) # num of path_lambda_gr
    list_all = c()
    coeff = coef.vcm(object,s) # coeff is a list
    for (i in 1:num_gr) {
      num_fuse = length(object[[i]]$path_lambda_fuse)
      tmp = vector(mode="list",(num_fuse))
      for (j in 1:num_fuse) {
        id = (i-1)*num_fuse+j
        #print(id)
        tmp[[j]] = row_times_row(newx, coeff[[i]][[j]])
      }
      list_all = c(list_all, tmp)
    }
    out = do.call(cbind, list_all)
    # out is a matrix with each column corresponding to the predicted values from a value of lambda_fuse
    # at one lambda_gr, the path of lambda_fuse; then repeat for the 2nd lambda_gr
  }
  return(out)
}

row_times_row=function(mat_x, mat_beta){

  if (class(mat_beta) == "list") {
    if (length(mat_beta) == 1) {
      mat_beta = as.matrix(mat_beta[[1]])
    } else {
      print("warning: in function row_times_row, mat_beta is a list with length > 1.")
    }
  }
  if (class(mat_beta) != "matrix") mat_beta = as.matrix(mat_beta)
  if (class(mat_x) != "matrix") mat_x = as.matrix(mat_x)

  num = nrow(mat_x)
  out = rep(NA, num)
  for (j in 1:num) {
    # https://stats.stackexchange.com/questions/377062/large-value-of-x-beta-in-logistic-regression
    tmp = sum(mat_x[j,]*mat_beta[j,]) #xbeta
    out[j] = plogis(tmp, lower.tail=TRUE)
  }
  return(out)
}




# convert back to original scale
return_original_scale = function(res, standardize, intercept, sx, bx){
  beta_mat_original = res$z2_mat # starting to convert beta to the original scale # update to z2_mat 02202019
  # beta_mat is a matrix of size n x p(+1 if intercept)
  if (standardize) {
    if (intercept) {
      # for each row in beta
      # https://stats.stackexchange.com/questions/376259/penalize-the-intercept-in-lasso-l1-penalized-logistic-regression-or-not
      beta_mat_original[,-1] = t(apply(beta_mat_original[,-1],MARGIN=1,original_scale, sx=sx[-1])) # coefficients not including the intercept
      beta_mat_original[,1] = beta_mat_original[,1] - apply(beta_mat_original[,-1],MARGIN=1,original_scale, bx=bx[-1])  # the intercept
    } else {
      if (ncol(beta_mat_original) == 1) {
        beta_mat_original = apply(beta_mat_original,MARGIN=1,original_scale, sx=sx)
        beta_mat_original = matrix(beta_mat_original, ncol=1)
      } else {
        #
        beta_mat_original = t(apply(beta_mat_original,MARGIN=1,original_scale, sx=sx)) # coefficients with no intercept
      }
    }
  }
  return(beta_mat_original)
}


# this function returns the original scale, given the beta in vector
# beta is a vector
# sx is a vector
original_scale = function(beta, sx= NULL, bx = NULL) {
  if (!is.null(sx)) return( beta/sx)
  if (!is.null(bx)) return(sum(beta * bx))
}

#' Centering and scaling convenience function
# only standardize x
# note here, x does not include the intercept column
# when x here include the intercept column, how
# when x here does not include intercept column, how

x_standardize = function(x, intercept, standardize = TRUE) {

  x = as.matrix(x)
  n = nrow(x)
  p = ncol(x)

  if (intercept) {
    bx = colMeans(x)
    x = scale(x,bx,FALSE)
  } else {
    bx = rep(0,p)
  }
  if (standardize) {
    sx = sqrt(colSums(x^2))
    x = scale(x,FALSE,sx)
  } else {
    sx = rep(1,p)
  }

  # addition care is needed when dealing with the intercept column in logistic regression when scaling x only
  if (intercept) {
    x[,1] = rep(1,n)
    bx[1] = 0
    sx [1] = 1
  }

  return(list(x=x,bx=bx,sx=sx))
}

# notes:
# for the fused only regression, the larger the lambda, it does not show the change points
# but letting the coefficients getting larger/smaller for smaller/larger lambda_fuse

