//#define EIGEN_USE_MKL_ALL
#include <RcppEigen.h>
#include <iostream>
#include <vector>
#include<Eigen/SparseCholesky>

using namespace Rcpp;
using namespace std;
using Eigen::MatrixXd;
using Eigen::SparseMatrix;
using Eigen::VectorXd;
using Eigen::Map;
using Eigen::LLT;
using Eigen::Lower;
using Eigen::VectorXd;
using Eigen::MappedSparseMatrix;
using Eigen::SparseMatrix;
using Rcpp::as;
using Rcpp::wrap;
// [[Rcpp::depends(RcppEigen)]]


// test for openmp
#include <omp.h>
// [[Rcpp::plugins(openmp)]]

// [[Rcpp::export]]
double sumsq_parallel(NumericVector x)
{
  double sum = 0.0;
omp_get_num_procs();
  #pragma omp parallel for shared(x) reduction(+:sum)
  for (int i=0; i<x.size(); i++){
	cout << i << ", " <<  omp_get_thread_num() <<  " of " <<  omp_get_num_threads()  << endl;
    sum += x(i)*x(i);
  }
  return sum;
}
//////////////


// [[Rcpp::export]]
SEXP eigenMatMult(Eigen::MatrixXd A, Eigen::MatrixXd B){
    Eigen::MatrixXd C = A * B;

    return Rcpp::wrap(C);
}

// [[Rcpp::export]]
SEXP eigenMatMult_t(Eigen::MatrixXd A, Eigen::MatrixXd B){
    Eigen::MatrixXd C = A.transpose() * B;

    return Rcpp::wrap(C);
}


// [[Rcpp::export]]
SEXP eigenMapMatMult(Eigen::Map<Eigen::MatrixXd> A, Eigen::Map<Eigen::MatrixXd> B){
    Eigen::MatrixXd C = A * B;

    return Rcpp::wrap(C);
}

// ref: https://stackoverflow.com/questions/35923787/fast-large-matrix-multiplication-in-r


// Sparse matrix operations
// ref: http://permalink.gmane.org/gmane.comp.lang.r.rcpp/8403
// sparse operations: https://eigen.tuxfamily.org/dox/group__SparseQuickRefPage.html


using Eigen::Map;
using Eigen::SparseMatrix;
using Eigen::LLT;

// t(sparse mat) * sparse mat
// [[Rcpp::export]]
SEXP sparse_eigenMatMult_t(Eigen::SparseMatrix<double> A, Eigen::SparseMatrix<double> B){
    Eigen::SparseMatrix<double> C = A.transpose() * B; // C is sparse
    // Eigen::MatrixXd dense_C = Eigen::MatrixXd(C);
    // return Rcpp::wrap(dense_C);
    return Rcpp::wrap(C);
}

// sparse mat * scalar
// [[Rcpp::export]]
SEXP sparse_eigenMatMultScalar(double s, Eigen::SparseMatrix<double> B){
    Eigen::SparseMatrix<double> C =  B * s; // C is sparse
    return Rcpp::wrap(C);
}


// sparse mat * dense mat
// [[Rcpp::export]]
SEXP sparse_dense_mult(Eigen::SparseMatrix<double> A, Eigen::MatrixXd B){
    Eigen::MatrixXd C = A * B; // C is sparse
    return Rcpp::wrap(C);
}

// these two pred functions below have problems
// x and B have different rows
// pred logit_
// [[Rcpp::export]]
SEXP sparse_dense_pred_logit_(Eigen::SparseMatrix<double> A, Eigen::MatrixXd B){
    Eigen::MatrixXd C = 1.0 - 1.0/(1.0+(A * B).array().exp()); // C is sparse
    return Rcpp::wrap(C);
}

// pred logit_
// [[Rcpp::export]]
SEXP dense_dense_pred_logit_(Eigen::MatrixXd x, Eigen::MatrixXd B){
  int num_obs, num_p;
  num_obs = x.rows();
  num_p = x.cols();

  Eigen::VectorXd tmp_x_col;
  Eigen::SparseMatrix<double> x_expand(num_obs,num_obs*num_p);
  // expand x
  // https://eigen.tuxfamily.org/dox/group__TutorialSparse.html
  x_expand.reserve(VectorXd::Constant(num_obs*num_p,1));
  int start;
  for (int i=0; i < num_p; i++) {
    tmp_x_col = x.col(i);
    // cout<< "col is" << tmp_x_col << endl;

    start = i*num_obs;
    for (int j=0; j < num_p; j++) {
      int new_j = j + start;
      x_expand.insert(j,new_j) = tmp_x_col(j);
    }
  }

    Eigen::MatrixXd C = 1.0 - 1.0/(1.0+(x_expand * B).array().exp());
    return Rcpp::wrap(C);
}








// sparse identical
// // [[Rcpp::export]]
//SEXP sparse_identical_mat(int num_row){
//    Eigen::SparseMatrix<double> C =  B * s; // C is sparse
//    return Rcpp::wrap(C);
//}

