////#define EIGEN_USE_MKL_ALL
#include <RcppEigen.h>
#include <iostream>
#include <vector>
#include<Eigen/SparseCholesky>

using namespace Rcpp;
using namespace std;
using Eigen::MatrixXd;
using Eigen::SparseMatrix;
using Eigen::VectorXd;
using Eigen::Map;
using Eigen::LLT;
using Eigen::Lower;
using Eigen::VectorXd;
using Eigen::MappedSparseMatrix;
using Eigen::SparseMatrix;
using Rcpp::as;
using Rcpp::wrap;

// [[Rcpp::depends(RcppEigen)]]

#include <omp.h>
// [[Rcpp::plugins(openmp)]]

// [[Rcpp::export]]
List test_logit_(Eigen::MatrixXd A){
	int num = A.rows();
  Eigen::VectorXd C;
	Eigen::MatrixXd D, E;
	C = 1/(exp(-A.array()) + 1);
	D = C.matrix();
	E = 1/(exp(-A.array()) + 1);
//     for (int i=0; i<num; i++) {
// 	C(i,0)=1/(1+exp(-A(i,0))); // the column 1 is indexed as 0 // no need for-llop for element-wise operations
//}

    return List::create(Named("C") = C, Named("D") = D, Named("E") = E, Named("E_elem") = E(0,0));
}




// the function logit in cpp for dense matrix
// [[Rcpp::export]]
Eigen::MatrixXd logit_(const Eigen::MatrixXd A){
  Eigen::MatrixXd E;
  E = 1/(exp(-A.array()) + 1);
  return (E);
}
// qq = matrix(c(1,2,3,4),ncol=1)
// logit_(qq)

// [[Rcpp::export]]
List test1(const Eigen::SparseMatrix<double> x, const Eigen::VectorXd w){
  Eigen::SparseMatrix<double> out;
  out =  x.transpose() * w.asDiagonal() * x;

  return List::create(Named("xtwx")=out);
}





////////////////////////////
// the function nlogl_logit_groupNfused in cpp
// Eigen::SparseMatrix<double>  x
// [[Rcpp::export]]
double nlogl_logit_groupNfused_(const Eigen::MatrixXd beta, const Eigen::SparseMatrix<double>  x, const Eigen::MatrixXd response, const Eigen::MatrixXd u1, const Eigen::MatrixXd z1,
                                double rho1, Eigen::SparseMatrix<double>  F1, const Eigen::MatrixXd u2,  const Eigen::MatrixXd z2,  double rho2, double eps=1e-32, bool aug_term=true){

  Eigen::MatrixXd p_temp,one_prob, prob, one_response, term1, term2;
  double tmp;

  int num_obs = response.rows();
  p_temp=logit_(Eigen::MatrixXd(x * beta));

  prob.setZero(num_obs,1);

  for (int i=0; i< num_obs; i++) {
    tmp = p_temp(i,0);
    if (tmp == 0.0) {
      prob(i,0) = eps;
    }
    else if (tmp == 1.0){
      prob(i,0) = tmp - eps;
    }
    else {
      prob(i,0) = tmp;
    }
  }

  one_prob = 1-prob.array();
  one_response = 1-response.array();

  double out;
  Eigen::MatrixXd out1, out2;

  out1 = prob.array().log() * response.array();
  out2 = one_prob.array().log() * one_response.array();

  out =  -out1.sum() - out2.sum();

  if (aug_term == true) {
    term1 = F1 * beta - z1 + u1;
    term2 = beta - z2 + u2;
    out = out + 0.5*rho1*term1.norm() + 0.5*rho2*term2.norm();
  }

  return (out);
}





//////////////////////////
// [[Rcpp::export]]
Eigen::MatrixXd updateX_logit_groupNfused_(Eigen::MatrixXd par, Eigen::SparseMatrix<double> x, Eigen::MatrixXd response, Eigen::MatrixXd u1, Eigen::MatrixXd z1,
                                double rho1, Eigen::SparseMatrix<double> F1, Eigen::MatrixXd u2,  Eigen::MatrixXd z2, double rho2,
                                Eigen::SparseMatrix<double> rhoF1tF1, Eigen::SparseMatrix<double> rhoF2tF2,
                                int iter_admm = 1, double eps=1e-32, double tol = 1e-4){
  int convergence = 0;
  Eigen::MatrixXd beta, beta_tmp;
  int maxiter;
  bool backtracking;

  beta = par;

  if(iter_admm == 1) { //iter_admm used as flag_iter_admm
    maxiter = 20;
    backtracking = true;
  } else {
    maxiter = 1;
    backtracking = false;
  }

  int num_obs = response.rows();

  double tmp, fn, fn_tmp;
  Eigen::MatrixXd p_temp,one_prob, prob, one_response, F1beta_z1_u1, F2beta_z2_u2, grad, w_mat, delta_beta, delta_fn;
  Eigen::VectorXd w;
  Eigen::SparseMatrix<double> x_w, hess;

  std::vector<double> fn_path;
  std::vector<double> delta_fn_path;

  for (int k=0; k < maxiter; k++) {
    // nlogl
    p_temp=logit_(Eigen::MatrixXd(x * beta));
    prob.setZero(num_obs,1);

    for (int i=0; i< num_obs; i++) {
      tmp = p_temp(i,0);
      if (tmp == 0.0) {
        prob(i,0) = eps;
      }
      else if (tmp == 1.0){
        prob(i,0) = tmp - eps;
      }
      else {
        prob(i,0) = tmp;
      }
    }

    one_prob = 1-prob.array();
    one_response = 1-response.array();

    double out;
    Eigen::MatrixXd out1, out2;

    out1 = prob.array().log() * response.array();
    out2 = one_prob.array().log() * one_response.array();
    fn =  -out1.sum() - out2.sum();

    F1beta_z1_u1 = F1 * beta - z1 + u1;
    F2beta_z2_u2 = beta - z2 + u2; //F2 is identity matrix
    fn = fn + 0.5*rho1*F1beta_z1_u1.norm() + 0.5*rho2*F2beta_z2_u2.norm();
    fn_path.push_back(fn);

    // gradient
    grad = - x.transpose() * (response - prob) + rho1 * (F1.transpose() *F1beta_z1_u1) + rho2 *F2beta_z2_u2 ;

    // hessian
    w = prob.array() *  one_prob.array();

    hess = x.transpose() * w.asDiagonal() * x + rhoF1tF1 + rhoF2tF2;

    Eigen::SimplicialLDLT <SparseMatrix<double> > solver;
    solver.compute(hess);
    // if(solver.info()!=Success) {
    //   // decomposition failed
    //   return;
    // }
    delta_beta = solver.solve(-grad);
    // if(solver.info()!=Success) {
    //   // solving failed
    //   return;
    // }

    delta_fn = -grad.transpose() * delta_beta; //delta_fn is 1by1 mat
    delta_fn_path.push_back(delta_fn(0,0));

    if (delta_fn(0,0) < tol) {
      convergence = 1;
      break;
    }
    //line back tracking
    double tt, fn_tmp_old, flag1;
    int counter =0;
    tt = 1;
    fn_tmp_old = fn;

    while (backtracking) {
      beta_tmp = beta + tt * delta_beta;
      fn_tmp =  nlogl_logit_groupNfused_(beta, x, response, u1, z1, rho1, F1, u2, z2, rho2, eps);
      flag1  = (fn_tmp_old - fn_tmp)/fn_tmp;
      if (std::abs(flag1) < 1e-2) { break; }
      if (fn_tmp <= (fn + 0.1 * tt*delta_fn(0,0))) {break;}
      tt = 0.5 * tt;
      fn_tmp_old = fn_tmp;
      counter +=1;
    }

    beta = beta + tt * delta_beta;
  }
  return beta;

 // return List::create(Named("beta") = beta,Named("convergence") = convergence, Named("delta_fn_path") = delta_fn_path);
}




//////////////////////////
// shrinkage_ function
// [[Rcpp::export]]
Eigen::MatrixXd shrinkage_(Eigen::MatrixXd x, double kappa, bool grLASSO = false){
  Eigen::MatrixXd z;

  if (grLASSO == false) {
    z = (x.array()-kappa).max(0) - (-x.array()-kappa).max(0) ;

  } else {
    z = std::max((1-kappa/x.norm()),0.0) * x;
  }
  return (z);
}


// test_cv_folds_
//////////////////////////////
// [[Rcpp::export]]
List test_cv_folds_(int num_obs, int numFolds, Eigen::MatrixXd x, Eigen::MatrixXd response){

  Environment rDLR("package:rDLR");
  Function cv_folds_ = rDLR["cv_folds_full"];

 // NumericMatrix folds = cv_folds_(num_obs, numFolds);
//  Eigen::MatrixXd  folds_mat(as<Map<MatrixXd> >(folds));
List out = cv_folds_(num_obs, numFolds, x, response);
  List out1;
  Eigen::MatrixXd xtest, xtrain, ytest, ytrain;

    out1 = out[1];
    xtest = out1[0];
    xtrain = out1[1];
    ytest = out1[2];
    ytrain = out1[3];

  List return1(5), return2(5);
  // 
  return1[0] = 1;
  return2[0] = 2;
  return1[1] = return2;

return(return1);
}


// F2 identity matrix
// [[Rcpp::export]]
Eigen::SparseMatrix<double> F2_(int num_obs, int num_col){
  // Eigen::SparseMatrix<double> F2;
  // // Eigen::MatrixXd F2;
  // F2.setIdentity(num_obs*num_col, num_obs*num_col);

  Environment rDLR("package:rDLR");
  Function diagonal_sp_ = rDLR["diagonal_sp"];

  int n=num_obs * num_col;
  SEXP F2 = diagonal_sp_(n, true);
  typedef Eigen::SparseMatrix<double> SpMat;
  SpMat F2_sp(Rcpp::as<SpMat>(F2));
  return(F2_sp);
}

// F1 diff_matrix
//////////////////////////////
// [[Rcpp::export]]
Eigen::SparseMatrix<double>  F1_(int num_obs, int num_col){

  Environment rDLR("package:rDLR");
  Function diff_matrix_ = rDLR["diff_matrix"];

  //NumericMatrix folds = cv_folds_(num_obs, numFolds);
  //Eigen::MatrixXd  folds_mat(as<Map<MatrixXd> >(folds));
  // NumericMatrix F1 = diff_matrix_(num_obs, false, num_col);
  // Eigen::MatrixXd  F1_mat(as<Map<MatrixXd> >(F1));
  // Eigen::SparseMatrix<double> F1_sp = F1_mat.sparseView();
  SEXP F1 = diff_matrix_(num_obs, true, num_col);

  typedef Eigen::SparseMatrix<double> SpMat;
  SpMat F1_sp(Rcpp::as<SpMat>(F1));
  // ref: http://gallery.rcpp.org/articles/sparse-matrix-coercion/

  // Eigen:MatrixXd D;
  // Eigen::SparseMatrix<double> E;
  // D.setIdentity(num_obs,num_obs);
  // E = D.sparseView();
  return (F1_sp);
}


//////////////////////////
// median_ function
// http://www.sanfoundry.com/cpp-program-compute-median-numbers/
// [[Rcpp::export]]
double median_( std::vector<double> v){
  double median;

  sort(v.begin(), v.end());
  if (v.size() % 2 == 0)
              median = (v[v.size()/2.0 - 1] + v[v.size()/2.0]) / 2.0;
    else
               median = v[v.size()/2.0];
  return (median);
}


//////////////////////////
// [[Rcpp::export]]
List admmLASSO_groupNfused_sep_(Eigen::MatrixXd x, Eigen::MatrixXd response, double lambda_fuse = 1.0, double lambda_gr = 1.0, std::string family = "logit", bool fused_lasso = true, bool group_lasso = true,
                                double ABSTOL = 1e-4, double RELTOL = 1e-2, int num_iterADMM = 1e3, int maxiter = 1, double eps=1e-32, int eta = 2, int cst_mu = 10, bool verbose=true){

  int num_obs = response.rows();
  int num_p = x.cols();
  lambda_fuse = num_obs * lambda_fuse;
  lambda_gr = num_obs * lambda_gr* std::sqrt(1);

  double rho1, rho2;
  Eigen::MatrixXd beta, u1, u2, z1, z2, beta_new, beta_tmp, zold1, zold2, F1_beta_new, F2_beta_new, uold1, uold2, fitted, z2_mat, beta_mat;
  bool flag_intercept;
  if ( (x.col(0).array()-1).isZero(0) ) {flag_intercept = true;} else { flag_intercept = false;}

  rho1 = std::sqrt(lambda_fuse) + 0.1;
  rho2 = rho1;

  Eigen::SparseMatrix<double> F1, F1tF1, F2, F2tF2;
  Eigen::MatrixXd F2_dm;

  F1 = F1_(num_obs, num_p);
  F1tF1 = F1.transpose() * F1;
  // F2_dm.setIdentity(num_obs*num_p, num_obs*num_p);
  // F2 = F2_dm.sparseView();
  F2 = F2_(num_obs, num_p);
  F2tF2 = F2;

  //if null init
  //beta.setZero(num_obs,0); // this is for sequential mean model
  beta.setZero(num_obs*num_p,1); // this is init for beta

  int num_rowF1 = F1.rows();
  int num_rowF2 = beta.rows();
  u1.setZero(num_rowF1,1);
  z1 = u1;
  u2.setZero(num_rowF2,1);
  z2 = u2;

  Eigen::VectorXd tmp_x_col;
  Eigen::SparseMatrix<double> x_expand(num_obs,num_obs*num_p);
  // expand x
  // https://eigen.tuxfamily.org/dox/group__TutorialSparse.html
  x_expand.reserve(VectorXd::Constant(num_obs*num_p,1));
  int start, new_j;
  for (int i=0; i < num_p; i++) {
    tmp_x_col = x.col(i);

    start = i*num_obs;
    for (int j=0; j < num_obs; j++) {
      new_j = j + start;
        x_expand.insert(j,new_j) = tmp_x_col(j);
    }
  }
  //x_expand.makeCompressed();

  std::vector<double> history_objval, history_r_norm, history_s_norm, history_eps_pri, history_eps_dual, history_r_norm2, history_s_norm2, history_eps_pri2, history_eps_dual2, rho1_path,rho2_path;
  int convergence, flag_maxiter, flag_rho1, flag_rho2;
  double obj1=0.0, obj2=0.0, obj_tmp;

  convergence =0;
  flag_maxiter=0;
  flag_rho1=0;
  flag_rho2=0;
  Eigen::SparseMatrix<double> rhoF1tF1, rhoF2tF2;

  rhoF1tF1 = rho1 * F1tF1;
  rhoF2tF2 = rho2 * F2tF2;
  if (verbose) cout << "ADMM iteration for the pair of lambdas_fusse "<< lambda_fuse <<" and "<< lambda_gr <<" starts " << endl;

for (int k=0; k < num_iterADMM; k++) {
    rho1_path.push_back(rho1);
    rho2_path.push_back(rho2);

    if (flag_rho1 == 0) {
      rhoF1tF1 = rho1 * F1tF1;
    }
    if (flag_rho2 == 0) {
      rhoF2tF2 = rho2 * F2tF2;
    }

    if (family == "logit") {
      beta_tmp = updateX_logit_groupNfused_(beta, x_expand, response, u1, z1, rho1, F1, u2, z2, rho2, rhoF1tF1, rhoF2tF2, flag_maxiter,  1e-16, 1e-4);
    }
    if (family == "gaussian") {

    }
    beta_new = beta_tmp; 

    // LASSO_step
    zold2 = z2;
    if (group_lasso == true) {
        for (int kk=0; kk < num_p; kk++) {
          int start_ind;
          start_ind = num_obs*kk;

        if (flag_intercept == true & kk == 0) { // do not penalize intercept
          z2.block(start_ind,0,num_obs,1) = beta_new.block(start_ind,0,num_obs,1);
        } else {
          z2.block(start_ind,0,num_obs,1) = shrinkage_(beta_new.block(start_ind,0,num_obs,1) + u2.block(start_ind,0,num_obs,1), lambda_gr/rho2, true);
        }

        }
    }

    zold1 = z1;
    F1_beta_new = F1 * beta_new;
    F2_beta_new = beta_new;

    if (fused_lasso == true) {
       z1 = shrinkage_(F1_beta_new + u1, lambda_fuse / rho1);
    }


    // u-step
    uold1 = u1;
    uold2 = u2;
    u1 = u1 + (F1_beta_new - z1);
    u2 = u2 + (F2_beta_new - z2);

    // termination check
    if (fused_lasso == true) {
      obj1 = F1_beta_new.lpNorm<1>();
    }

    if (group_lasso == true) {
      obj2 = 0.0;
      for (int kk=0; kk < num_p; kk++) {
        int start_ind;
        start_ind = num_obs*kk;

        if (flag_intercept == true & kk == 0) {
          // do nothing
        } else {
          obj2 = obj2 + z2.block(start_ind,0,num_obs,1).norm();
        }
      }
    }
    if (family == "logit") {
      obj_tmp = nlogl_logit_groupNfused_(beta_new, x_expand, response, u1, z1, rho1, F1, u2, z2, rho2, 1e-16, false) + lambda_fuse * obj1 + lambda_gr * obj2;
    }
    if (family == "gaussian") {
      //obj_tmp
    }

    history_objval.push_back(obj_tmp);
    history_r_norm2.push_back((F2_beta_new-z2).norm());
    history_s_norm2.push_back(rho2*(z2-zold2).norm());

    history_r_norm.push_back((F1_beta_new-z1).norm());
    history_s_norm.push_back((rho1*F1.transpose()*(z1-zold1)).norm());

    history_eps_pri2.push_back(sqrt(F2.rows()) * ABSTOL + RELTOL * max(z2.norm(),F2_beta_new.norm()));
    history_eps_dual2.push_back(sqrt(num_obs) * ABSTOL + RELTOL * (rho2*u2).norm());

    history_eps_pri.push_back(sqrt(F1.rows()) * ABSTOL + RELTOL * max (F1_beta_new.norm(),z1.norm()) );
    history_eps_dual.push_back(sqrt(num_obs) * ABSTOL + RELTOL * (rho1 * F1.transpose() * u1).norm());

    beta = beta_new;

    // stop condition
    if (history_r_norm[k] <= history_eps_pri[k] & history_s_norm[k] <= history_eps_dual[k] &
        history_r_norm2[k] <= history_eps_pri2[k] & history_s_norm2[k] <= history_eps_dual2[k]) {
      convergence = 1;
      break;
    }

    // tune the parameters rho
    int counter =0;
    if (k > 0) {
      if (history_r_norm[k-1]<history_r_norm[k]) counter +=1;
      if (history_eps_pri[k-1]<  history_eps_pri[k]) counter +=1;
      if (history_s_norm[k-1] < history_s_norm[k]) counter +=1;
      if (history_eps_dual[k-1]<   history_eps_dual[k]) counter +=1;
      if (history_r_norm2[k-1]< history_r_norm2[k]) counter +=1;
      if (history_eps_pri2[k-1]< history_eps_pri2[k]) counter +=1;
      if (history_s_norm2[k-1] < history_s_norm2[k]) counter +=1;
      if (history_eps_dual2[k-1]< history_eps_dual2[k]) counter +=1;

      if (counter > 6) {flag_maxiter = 1;} else {flag_maxiter = 0;}
    }

    if (history_r_norm[k]/ history_eps_pri[k] >= cst_mu*history_s_norm[k]/ history_eps_dual[k]) {
      rho1 = eta * rho1;
      u1 = 1.0/eta * u1;
    } else if (cst_mu*history_r_norm[k]/ history_eps_pri[k] <= history_s_norm[k]/ history_eps_dual[k]) {
      rho1 = 1.0/eta * rho1;
      u1 = eta * u1;
    } else {
      flag_rho1 = 1;
      }

    if (history_r_norm2[k]/ history_eps_pri2[k] >= cst_mu*history_s_norm2[k]/ history_eps_dual2[k]) {
      rho2 = eta * rho2;
      u2 = 1.0/eta * u2;
    } else if (cst_mu*history_r_norm2[k]/ history_eps_pri2[k] <= history_s_norm2[k]/ history_eps_dual2[k]) {
      rho2 = 1.0/eta * rho2;
      u2 = eta * u2;
    } else {
      flag_rho2 = 1;
      }

  }

    Rcpp::DataFrame history = Rcpp::DataFrame::create(Named("history_objval") = history_objval, Named("history_r_norm") = history_r_norm, Named("history_eps_pri") =history_eps_pri
      , Named("history_s_norm") = history_s_norm, Named("history_eps_dual") = history_eps_dual, Named("history_r_norm2") = history_r_norm2,
              Named("history_eps_pri2") = history_eps_pri2, Named("history_s_norm2") = history_s_norm2, Named("history_eps_dual2") = history_eps_dual2);

  if (family == "logit") {
    fitted=  1.0 - 1.0/(1.0+(x_expand * z2).array().exp());
  }
  if (family == "gaussian") {
    // fitted=  x%*%beta
  }

beta_mat = beta;
beta_mat.resize(num_obs,num_p);
z2_mat = z2;
z2_mat.resize(num_obs,num_p);

  return List::create(Named("beta_mat") = beta_mat, Named("beta") = beta, Named("convergence") = convergence, Named("x_expand") = x_expand
                        , Named("response") = response, Named("u1") = u1, Named("u2") = u2
                        , Named("z1") = z1, Named("z2") = z2, Named("z2_mat") = z2_mat, Named("rho1_path") = rho1_path, Named("rho2_path") = rho2_path
                        , Named("lambda_fuse") = lambda_fuse, Named("lambda_gr") = lambda_gr
                        , Named("F1") = F1, Named("rhoF1tF1") = rhoF1tF1, Named("rhoF2tF2") =   rhoF2tF2
                        , Named("flag_maxiter") = flag_maxiter
                        , Named("history") = history, Named("fitted") = fitted
                        );

  }



// recreacted a new cv function in Rcpp
// [[Rcpp::export]]
List admmLASSO_groupNfused_sep2_(Eigen::MatrixXd x, Eigen::MatrixXd response, Eigen::MatrixXd beta, double rho1, double rho2, Eigen::SparseMatrix<double> F1, Eigen::SparseMatrix<double> F1tF1,
                                Eigen::SparseMatrix<double> F2, Eigen::SparseMatrix<double> F2tF2, double lambda_fuse = 1.0, double lambda_gr = 1.0, std::string family = "logit", bool fused_lasso = true, bool group_lasso = true,
                                double ABSTOL = 1e-4, double RELTOL = 1e-2, int num_iterADMM = 1e3, int maxiter = 1, double eps=1e-32, int eta = 2, int cst_mu = 10){

  int num_obs = response.rows();
  int num_p = x.cols();

  lambda_fuse = num_obs * lambda_fuse;
  lambda_gr = num_obs * lambda_gr * std::sqrt(1);

  //double rho1, rho2;
  Eigen::MatrixXd u1, u2, z1, z2, beta_new, beta_tmp, zold1, zold2, F1_beta_new, F2_beta_new, uold1, uold2, fitted, z2_mat, beta_mat;
  bool flag_intercept;
  if ( (x.col(0).array()-1).isZero(0) ) {flag_intercept = true;} else { flag_intercept = false;}
  int num_rowF1 = F1.rows();
  int num_rowF2 = beta.rows();
  u1.setZero(num_rowF1,1);
  z1 = u1;
  u2.setZero(num_rowF2,1);
  z2 = u2;

  Eigen::VectorXd tmp_x_col;
  Eigen::SparseMatrix<double> x_expand(num_obs,num_obs*num_p);
  // expand x
  // https://eigen.tuxfamily.org/dox/group__TutorialSparse.html
  x_expand.reserve(VectorXd::Constant(num_obs*num_p,1));
  int start, new_j;
  for (int i=0; i < num_p; i++) {
    tmp_x_col = x.col(i);

    start = i*num_obs;
    for (int j=0; j < num_obs; j++) {
      new_j = j + start;
      x_expand.insert(j,new_j) = tmp_x_col(j);
    }
  }
  //x_expand.makeCompressed();

  std::vector<double> history_objval, history_r_norm, history_s_norm, history_eps_pri, history_eps_dual, history_r_norm2, history_s_norm2, history_eps_pri2, history_eps_dual2, rho1_path,rho2_path;
  int convergence, flag_maxiter, flag_rho1, flag_rho2;
  double obj1=0.0, obj2 =0.0, obj_tmp;

  convergence =0;
  flag_maxiter=0;
  flag_rho1=0;
  flag_rho2=0;
  Eigen::SparseMatrix<double> rhoF1tF1, rhoF2tF2;

  rhoF1tF1 = rho1 * F1tF1;
  rhoF2tF2 = rho2 * F2tF2;
  cout << "ADMM iteration for a pair lambdas "<< lambda_fuse <<" and "<< lambda_gr <<" starts " << endl;

  for (int k=0; k < num_iterADMM; k++) {
    rho1_path.push_back(rho1);
    rho2_path.push_back(rho2);

    if (flag_rho1 == 0) {
      rhoF1tF1 = rho1 * F1tF1;
    }
    if (flag_rho2 == 0) {
      rhoF2tF2 = rho2 * F2tF2;
    }

    if (family == "logit") {
      beta_tmp = updateX_logit_groupNfused_(beta, x_expand, response, u1, z1, rho1, F1, u2, z2, rho2, rhoF1tF1, rhoF2tF2, flag_maxiter,  1e-16, 1e-4);
    }
    if (family == "gaussian") {
      //
    }
    beta_new = beta_tmp;

    // LASSO_step
    zold2 = z2;
    if (group_lasso == true) {
      for (int kk=0; kk < num_p; kk++) {
        int start_ind;
        start_ind = num_obs*kk;

        if (flag_intercept == true & kk == 0) { // do not penalize intercept
          z2.block(start_ind,0,num_obs,1) = beta_new.block(start_ind,0,num_obs,1);
        } else {
          z2.block(start_ind,0,num_obs,1) = shrinkage_(beta_new.block(start_ind,0,num_obs,1) + u2.block(start_ind,0,num_obs,1), lambda_gr/rho2, true);
        }

      }
    }

    zold1 = z1;
    F1_beta_new = F1 * beta_new;
    F2_beta_new = beta_new;

    if (fused_lasso == true) {
      z1 = shrinkage_(F1_beta_new + u1, lambda_fuse / rho1);
    }


    // u-step
    uold1 = u1;
    uold2 = u2;
    u1 = u1 + (F1_beta_new - z1);
    u2 = u2 + (F2_beta_new - z2);

    // termination check
    if (fused_lasso == true) {
      obj1 = F1_beta_new.lpNorm<1>();
    }

    if (group_lasso == true) {
      obj2 = 0.0;
      for (int kk=0; kk < num_p; kk++) {
        int start_ind;
        start_ind = num_obs*kk;

        if (flag_intercept == true & kk == 0) {
          // do nothing
        } else {
          obj2 = obj2 + z2.block(start_ind,0,num_obs,1).norm();
        }
      }
    }
    if (family == "logit") {
      obj_tmp = nlogl_logit_groupNfused_(beta_new, x_expand, response, u1, z1, rho1, F1, u2, z2, rho2, 1e-16, false) + lambda_fuse * obj1 + lambda_gr * obj2;
    }
    if (family == "gaussian") {
      //obj_tmp
    }

    history_objval.push_back(obj_tmp);
    history_r_norm2.push_back((F2_beta_new-z2).norm());
    history_s_norm2.push_back(rho2*(z2-zold2).norm());

    history_r_norm.push_back((F1_beta_new-z1).norm());
    history_s_norm.push_back((rho1*F1.transpose()*(z1-zold1)).norm());

    history_eps_pri2.push_back(sqrt(F2.rows()) * ABSTOL + RELTOL * max(z2.norm(),F2_beta_new.norm()));
    history_eps_dual2.push_back(sqrt(num_obs) * ABSTOL + RELTOL * (rho2*u2).norm());

    history_eps_pri.push_back(sqrt(F1.rows()) * ABSTOL + RELTOL * max (F1_beta_new.norm(),z1.norm()) );
    history_eps_dual.push_back(sqrt(num_obs) * ABSTOL + RELTOL * (rho1 * F1.transpose() * u1).norm());

    beta = beta_new;

    // stop condition
    if (history_r_norm[k] <= history_eps_pri[k] & history_s_norm[k] <= history_eps_dual[k] &
        history_r_norm2[k] <= history_eps_pri2[k] & history_s_norm2[k] <= history_eps_dual2[k]) {
      convergence = 1;
      break;
    }

    // tune the parameters rho
    int counter =0;
    if (k > 0) {
      if (history_r_norm[k-1]<history_r_norm[k]) counter +=1;
      if (history_eps_pri[k-1]<  history_eps_pri[k]) counter +=1;
      if (history_s_norm[k-1] < history_s_norm[k]) counter +=1;
      if (history_eps_dual[k-1]<   history_eps_dual[k]) counter +=1;
      if (history_r_norm2[k-1]< history_r_norm2[k]) counter +=1;
      if (history_eps_pri2[k-1]< history_eps_pri2[k]) counter +=1;
      if (history_s_norm2[k-1] < history_s_norm2[k]) counter +=1;
      if (history_eps_dual2[k-1]< history_eps_dual2[k]) counter +=1;

      if (counter > 6) {flag_maxiter = 1;} else {flag_maxiter = 0;}
    }

    if (history_r_norm[k]/ history_eps_pri[k] >= cst_mu*history_s_norm[k]/ history_eps_dual[k]) {
      rho1 = eta * rho1;
      u1 = 1.0/eta * u1;
    } else if (cst_mu*history_r_norm[k]/ history_eps_pri[k] <= history_s_norm[k]/ history_eps_dual[k]) {
      rho1 = 1.0/eta * rho1;
      u1 = eta * u1;
    } else {
      flag_rho1 = 1;
    }

    if (history_r_norm2[k]/ history_eps_pri2[k] >= cst_mu*history_s_norm2[k]/ history_eps_dual2[k]) {
      rho2 = eta * rho2;
      u2 = 1.0/eta * u2;
    } else if (cst_mu*history_r_norm2[k]/ history_eps_pri2[k] <= history_s_norm2[k]/ history_eps_dual2[k]) {
      rho2 = 1.0/eta * rho2;
      u2 = eta * u2;
    } else {
      flag_rho2 = 1;
    }
    if (k == num_iterADMM) cout << "max ADMM iteration" << k << " is reached" << endl;


  }

  Rcpp::DataFrame history = Rcpp::DataFrame::create(Named("history_objval") = history_objval, Named("history_r_norm") = history_r_norm, Named("history_eps_pri") =history_eps_pri
                                                      , Named("history_s_norm") = history_s_norm, Named("history_eps_dual") = history_eps_dual, Named("history_r_norm2") = history_r_norm2,
                                                              Named("history_eps_pri2") = history_eps_pri2, Named("history_s_norm2") = history_s_norm2, Named("history_eps_dual2") = history_eps_dual2);

  if (family == "logit") {
    fitted=  1.0 - 1.0/(1.0+(x_expand * z2).array().exp());
  }
  if (family == "gaussian") {
    // fitted=  x%*%beta
  }

  beta_mat = beta;
  beta_mat.resize(num_obs,num_p);
  z2_mat = z2;
  z2_mat.resize(num_obs,num_p);

  return List::create(Named("beta_mat") = beta_mat, Named("beta") = beta, Named("convergence") = convergence, Named("x_expand") = x_expand
                        , Named("response") = response, Named("u1") = u1, Named("u2") = u2
                        , Named("z1") = z1, Named("z2") = z2, Named("z2_mat") = z2_mat, Named("rho1_path") = rho1_path, Named("rho2_path") = rho2_path
                        , Named("lambda_fuse") = lambda_fuse, Named("lambda_gr") = lambda_gr
                        , Named("F1") = F1, Named("rhoF1tF1") = rhoF1tF1, Named("rhoF2tF2") =   rhoF2tF2
                        , Named("flag_maxiter") = flag_maxiter
                        , Named("history") = history, Named("fitted") = fitted
  );

}


// x_expand_
// [[Rcpp::export]]
Eigen::SparseMatrix<double> x_expand_(Eigen::MatrixXd x){
  int num_obs, num_p;
  num_obs = x.rows();
  num_p = x.cols();

  Eigen::VectorXd tmp_x_col;
  Eigen::SparseMatrix<double> x_expand(num_obs,num_obs*num_p);
  // expand x
  // https://eigen.tuxfamily.org/dox/group__TutorialSparse.html
  x_expand.reserve(VectorXd::Constant(num_obs*num_p,1));
  int start, new_j;
  for (int i=0; i < num_p; i++) {
    tmp_x_col = x.col(i);
    start = i*num_obs;
    for (int j=0; j < num_obs; j++) {
      new_j = j + start;
      x_expand.insert(j,new_j) = tmp_x_col(j);
    }
  }
   return x_expand;
}


// old 
// pred logit_ based on the distance from the xtrain points
// [[Rcpp::export]]
Eigen::MatrixXd pred_dist_logit_(Eigen::MatrixXd xTest, Eigen::MatrixXd xRef, Eigen::MatrixXd coefRef){
  Eigen::MatrixXd obs;
  Eigen::MatrixXd dist_mat, coefTest, pred;
  Eigen::MatrixXf::Index minIndex;
  double value;
  int num_row, num_col, tmp;

  dist_mat.setZero(xRef.rows(),1);
  coefTest.setZero(xTest.rows(),coefRef.cols());

  for (int i=0; i < xTest.rows(); i++) {
    obs = xTest.row(i);

    // obtain the dist at each point
    for (int j=0; j < xRef.rows(); j++) {
      dist_mat(j,0) = (xRef.row(j) - obs).norm(); // calculate the distance
    }
    // select the index
    value = dist_mat.col(0).minCoeff( &minIndex);
    coefTest.row(i) = coefRef.row(minIndex);
 }

  num_row = coefTest.rows();
  num_col = coefTest.cols();
  tmp = num_row * num_col;
  coefTest.resize(tmp,1);

  // pred = x_expand_(xTest) * coefTest;
  pred = 1.0 - 1.0/(1.0+(x_expand_(xTest) * coefTest).array().exp());
  return (pred);
}


// cross-validation
// need argument lamb_path
////////////////////////
// [[Rcpp::export]]
SEXP cv_admmLASSO_groupNfused_sep_(Eigen::MatrixXd x, Eigen::MatrixXd response, Eigen::VectorXd lamb_path, int numFolds = 10, std::string family = "logit", bool fused_lasso = true, bool group_lasso = true,
                                double ABSTOL = 1e-4, double RELTOL = 1e-2, int num_iterADMM = 1e3, int maxiter = 1, double eps=1e-32, int eta = 2, int cst_mu = 10, bool verbose=true){

  int num_obs_raw = response.rows();
  int num_p_raw = x.cols();
  int size_lamb_path = lamb_path.size();
  int nrow_xtrain, ncol_xtrain, nrow_xtrain_old = 0;

  double lambda_fuse, lambda_gr;
  Environment rDLR("package:rDLR");
  Function cv_folds_ = rDLR["cv_folds_full"];
  Function coefTest_ = rDLR["coefTest"];

  Eigen::MatrixXd x_raw, response_raw;
  x_raw = x;
  response_raw = response;

  List out_L1(size_lamb_path);

  List folds = cv_folds_(num_obs_raw, numFolds, x_raw, response_raw);

  for (int ip=0; ip < size_lamb_path; ip ++) {
    lambda_fuse = lamb_path[ip];

    List out_L2(size_lamb_path);

 //   omp_get_num_procs();
//#pragma omp parallel for
    for (int jp=0; jp < size_lamb_path; jp++) {
      lambda_gr = lamb_path[jp] * std::sqrt(1);

      // NumericMatrix folds = cv_folds_(num_obs, numFolds);
      // Eigen::MatrixXd  folds_mat(as<Map<MatrixXd> >(folds));
      List part;
      Eigen::MatrixXd xtest, xtrain, ytest, ytrain, F2_dm;
      Eigen::SparseMatrix<double> F1, F1tF1, F2, F2tF2;

      List out_L3(numFolds);
      cout << "ADMM iteration for a pair lambdas "<< lambda_fuse <<" and "<< lambda_gr <<" starts " << endl;

      Eigen::MatrixXd beta;

      for (int kp=0; kp < numFolds; kp++) {
        if (verbose) cout << "in cv, fold id is " << kp << endl;
        part = folds[kp];
        xtest = part[0];
        x = xtrain = part[1];
        ytest = part[2];
        response = ytrain = part[3];
        nrow_xtrain = xtrain.rows();
        ncol_xtrain = xtrain.cols();

          F1 = F1_(nrow_xtrain, ncol_xtrain);
          F1tF1 = F1.transpose() * F1;
          // F2_dm.setIdentity(nrow_xtrain*ncol_xtrain, nrow_xtrain*ncol_xtrain);
          // F2 = F2_dm.sparseView();
          F2 = F2_(nrow_xtrain, ncol_xtrain);
          F2tF2 = F2;

        //////////////////////////
        // main admm code copied from admmLASSO_groupNfused_sep_
        int num_obs = response.rows();
        int num_p = x.cols();
       // lambda_fuse = num_obs * lambda_fuse;
        //lambda_gr = num_obs * lambda_gr * std::sqrt(num_obs); // old: lambda_gr = num_obs * lambda_gr;

        double rho1, rho2;
        Eigen::MatrixXd u1, u2, z1, z2, beta_new, beta_tmp, zold1, zold2, F1_beta_new, F2_beta_new, uold1, uold2, fitted, z2_mat, beta_mat;
        bool flag_intercept;
        if ( (x.col(0).array()-1).isZero(0) ) {flag_intercept = true;} else { flag_intercept = false;}

        rho1 = std::sqrt(lambda_fuse) + 0.1;
        rho2 = std::sqrt(lambda_gr) + 0.1;

        //beta.setZero(num_obs,0); // this is for sequential mean model
          beta.setZero(num_obs*num_p,1); // this is init for beta
          
        int num_rowF1 = F1.rows();
        int num_rowF2 = beta.rows();
        u1.setZero(num_rowF1,1);
        z1 = u1;
        u2.setZero(num_rowF2,1);
        z2 = u2;

        Eigen::VectorXd tmp_x_col;
        Eigen::SparseMatrix<double> x_expand(num_obs,num_obs*num_p);
        // expand x
        // https://eigen.tuxfamily.org/dox/group__TutorialSparse.html
        x_expand.reserve(VectorXd::Constant(num_obs*num_p,1));
        int start, new_j;
        for (int i=0; i < num_p; i++) {
          tmp_x_col = x.col(i);

          start = i*num_obs;
          for (int j=0; j < num_obs; j++) {
            new_j = j + start;
            x_expand.insert(j,new_j) = tmp_x_col(j);
          }
        }
        //x_expand.makeCompressed();

        std::vector<double> history_objval, history_r_norm, history_s_norm, history_eps_pri, history_eps_dual, history_r_norm2, history_s_norm2, history_eps_pri2, history_eps_dual2, rho1_path,rho2_path;
        int convergence, flag_maxiter, flag_rho1, flag_rho2;
        double obj1=0.0, obj2=0.0, obj_tmp;

        convergence =0;
        flag_maxiter=0;
        flag_rho1=0;
        flag_rho2=0;
        Eigen::SparseMatrix<double> rhoF1tF1, rhoF2tF2;

        rhoF1tF1 = rho1 * F1tF1;
        rhoF2tF2 = rho2 * F2tF2;

        for (int k=0; k < num_iterADMM; k++) {
          rho1_path.push_back(rho1);
          rho2_path.push_back(rho2);

          if (flag_rho1 == 0) {
            rhoF1tF1 = rho1 * F1tF1;
          }
          if (flag_rho2 == 0) {
            rhoF2tF2 = rho2 * F2tF2;
          }

          if (family == "logit") {
            beta_tmp = updateX_logit_groupNfused_(beta, x_expand, response, u1, z1, rho1, F1, u2, z2, rho2, rhoF1tF1, rhoF2tF2, flag_maxiter,  1e-16, 1e-4);
          }
          if (family == "gaussian") {

          }
          beta_new = beta_tmp; //

          // LASSO_step
          zold2 = z2;
          if (group_lasso == true) {
            for (int kk=0; kk < num_p; kk++) {

              int start_ind;
              start_ind = num_obs*kk;

              if (flag_intercept == true & kk == 0) { // do not penalize intercept
                z2.block(start_ind,0,num_obs,1) = beta_new.block(start_ind,0,num_obs,1);
              } else {
                z2.block(start_ind,0,num_obs,1) = shrinkage_(beta_new.block(start_ind,0,num_obs,1) + u2.block(start_ind,0,num_obs,1), lambda_gr/rho2, true);
              }

            }
          }

          zold1 = z1;
          F1_beta_new = F1 * beta_new;
          F2_beta_new = beta_new;

          if (fused_lasso == true) {
            z1 = shrinkage_(F1_beta_new + u1, lambda_fuse / rho1);
          }

          // u-step
          uold1 = u1;
          uold2 = u2;
          u1 = u1 + (F1_beta_new - z1);
          u2 = u2 + (F2_beta_new - z2);

          // termination check
          if (fused_lasso == true) {
            obj1 = F1_beta_new.lpNorm<1>();
          }

          if (group_lasso == true) {
            obj2 = 0.0;
            for (int kk=0; kk < num_p; kk++) {
              int start_ind;
              start_ind = num_obs*kk;

              if (flag_intercept == true & kk == 0) {
                // do nothing
              } else {
                obj2 = obj2 + z2.block(start_ind,0,num_obs,1).norm();
              }
            }
          }
          if (family == "logit") {
            obj_tmp = nlogl_logit_groupNfused_(beta_new, x_expand, response, u1, z1, rho1, F1, u2, z2, rho2, 1e-16, false) + lambda_fuse * obj1 + lambda_gr * obj2;
          }
          if (family == "gaussian") {
            //obj_tmp
          }

          history_objval.push_back(obj_tmp);
          history_r_norm2.push_back((F2_beta_new-z2).norm());
          history_s_norm2.push_back(rho2*(z2-zold2).norm());

          history_r_norm.push_back((F1_beta_new-z1).norm());
          history_s_norm.push_back((rho1*F1.transpose()*(z1-zold1)).norm());

          history_eps_pri2.push_back(sqrt(F2.rows()) * ABSTOL + RELTOL * max(z2.norm(),F2_beta_new.norm()));
          history_eps_dual2.push_back(sqrt(num_obs) * ABSTOL + RELTOL * (rho2*u2).norm());

          history_eps_pri.push_back(sqrt(F1.rows()) * ABSTOL + RELTOL * max (F1_beta_new.norm(),z1.norm()) );
          history_eps_dual.push_back(sqrt(num_obs) * ABSTOL + RELTOL * (rho1 * F1.transpose() * u1).norm());

          beta = beta_new;

          // stop condition
          if (history_r_norm[k] <= history_eps_pri[k] & history_s_norm[k] <= history_eps_dual[k] &
              history_r_norm2[k] <= history_eps_pri2[k] & history_s_norm2[k] <= history_eps_dual2[k]) {
            convergence = 1;
            break;
          }

          // tune the parameters rho
          int counter =0;
          if (k > 0) {
            if (history_r_norm[k-1]<history_r_norm[k]) counter +=1;
            if (history_eps_pri[k-1]<  history_eps_pri[k]) counter +=1;
            if (history_s_norm[k-1] < history_s_norm[k]) counter +=1;
            if (history_eps_dual[k-1]<   history_eps_dual[k]) counter +=1;
            if (history_r_norm2[k-1]< history_r_norm2[k]) counter +=1;
            if (history_eps_pri2[k-1]< history_eps_pri2[k]) counter +=1;
            if (history_s_norm2[k-1] < history_s_norm2[k]) counter +=1;
            if (history_eps_dual2[k-1]< history_eps_dual2[k]) counter +=1;

            if (counter > 6) {flag_maxiter = 1;} else {flag_maxiter = 0;}
          }

          if (history_r_norm[k]/ history_eps_pri[k] >= cst_mu*history_s_norm[k]/ history_eps_dual[k]) {
            rho1 = eta * rho1;
            u1 = 1.0/eta * u1;
          } else if (cst_mu*history_r_norm[k]/ history_eps_pri[k] <= history_s_norm[k]/ history_eps_dual[k]) {
            rho1 = 1.0/eta * rho1;
            u1 = eta * u1;
          } else {
            flag_rho1 = 1;
          }

          if (history_r_norm2[k]/ history_eps_pri2[k] >= cst_mu*history_s_norm2[k]/ history_eps_dual2[k]) {
            rho2 = eta * rho2;
            u2 = 1.0/eta * u2;
          } else if (cst_mu*history_r_norm2[k]/ history_eps_pri2[k] <= history_s_norm2[k]/ history_eps_dual2[k]) {
            rho2 = 1.0/eta * rho2;
            u2 = eta * u2;
          } else {
            flag_rho2 = 1;
          }

        } // ADMM iteration loop

        Rcpp::DataFrame history = Rcpp::DataFrame::create(Named("history_objval") = history_objval, Named("history_r_norm") = history_r_norm, Named("history_eps_pri") =history_eps_pri
                                                            , Named("history_s_norm") = history_s_norm, Named("history_eps_dual") = history_eps_dual, Named("history_r_norm2") = history_r_norm2,
                                                                    Named("history_eps_pri2") = history_eps_pri2, Named("history_s_norm2") = history_s_norm2, Named("history_eps_dual2") = history_eps_dual2);

        if (family == "logit") {
          fitted=  1.0 - 1.0/(1.0+(x_expand * z2).array().exp());
        }
        if (family == "gaussian") {
          // fitted=  x%*%beta
        }

        beta_mat = beta;
        beta_mat.resize(num_obs,num_p);
        z2_mat = z2;
        z2_mat.resize(num_obs,num_p);

        /////////////////////
        Eigen::VectorXd coef_index_left, coef_index_right, dist_prop, one_dist_prop;
        Eigen::MatrixXd pred_coef, pred;
        int num_row_test, num_col_test, tmp;


        coef_index_left = part[8]; // related to the R function cv_folds_full
        coef_index_right = part[9];
        dist_prop = part[10];
        one_dist_prop = part[11];

        NumericMatrix coef_test1 = coefTest_(z2_mat, coef_index_left, coef_index_right, one_dist_prop, dist_prop);
        Eigen::MatrixXd  coef_test(as<Map<MatrixXd> >(coef_test1));

        num_row_test = coef_test.rows();
        num_col_test = coef_test.cols();
        tmp = num_row_test * num_col_test;
        coef_test.resize(tmp,1);

        pred = 1.0 - 1.0/(1.0+(x_expand_(xtest) * coef_test).array().exp());

// Eigen::MatrixXd pred = pred_dist_logit_(xtest,xtrain,z2_mat);

        List out_part(16);
        out_part[0] = beta_mat;
        out_part[1] = beta;
        out_part[2] = z2_mat;
        out_part[3] = z2;
        out_part[4] = fitted;
        out_part[5] = response;
        out_part[6] = x_expand;
        out_part[7] = history;
        out_part[8] = convergence;
        out_part[9] = lambda_fuse;
        out_part[10] = lambda_gr;
        out_part[11] = rho1_path;
        out_part[12] = rho2_path;
        out_part[13] = flag_maxiter;
	      out_part[14]=pred;
	      out_part[15]=ytest;


        out_L3[kp] = out_part;
      }
      out_L2[jp] = out_L3;

    } // lambda_fuse loop
    out_L1[ip] = out_L2;
  } // lambda_gr loop

return(out_L1);

}


